package com.animoz.service;

public class IllegalEnclosException extends Exception {
	public IllegalEnclosException(String message) {
		super(message);
	}
}
