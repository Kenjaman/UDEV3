package com.exemple.spring;

public class Moteur {
	private int nbSoupapes;

	public int getNbSoupapes() {
		return nbSoupapes;
	}

	public void setNbSoupapes(int nbSoupapes) {
		this.nbSoupapes = nbSoupapes;
	}
	
}
