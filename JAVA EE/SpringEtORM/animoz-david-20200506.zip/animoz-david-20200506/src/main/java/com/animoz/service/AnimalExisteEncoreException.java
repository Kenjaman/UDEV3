package com.animoz.service;

public class AnimalExisteEncoreException extends Exception {

	public AnimalExisteEncoreException(String message) {
		super(message);
	}

}
