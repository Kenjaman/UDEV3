package com.bddjee.bdd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.bddjee.beans.Client;
import com.bddjee.beans.Produit;

public class Connexion {

	public ArrayList<Client> getConnexionClient() {
		Connection connexion = null;
		Statement statement = null;
		ResultSet resultSet = null;
		ArrayList<Client> clients = new ArrayList<Client>();
		
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			
			connexion = DriverManager.getConnection("jdbc:mariadb://localhost:3306/frontjee", "root", "toor");
			statement = connexion.createStatement();
			
			resultSet = statement.executeQuery("SELECT * FROM client;");
			
			while(resultSet.next()) {
				Client client = new Client(resultSet.getString("nom"), resultSet.getString("adress"), resultSet.getString("CP"), resultSet.getString("ville"));
				
				clients.add(client);
				
			}
			resultSet.close();
			statement.close();
			connexion.close();
		}catch (Exception e) {
			System.out.println("boulette en bdd !");
		}
		
		return clients;
	}
	
	public void getConnexionAjoutClient(Client client) {
		Connection connexion = null;


		try {
			Class.forName("org.mariadb.jdbc.Driver");
			
			connexion = DriverManager.getConnection("jdbc:mariadb://localhost:3306/frontjee", "root", "toor");
			PreparedStatement preparedStatement = connexion.prepareStatement("INSERT into client(nom, adress, CP, ville) values(?,?,?,?)");

			preparedStatement.setString(1, client.getNom());
			preparedStatement.setString(2, client.getAdress());
			preparedStatement.setString(3, client.getCP());
			preparedStatement.setString(4, client.getVille());
			
			preparedStatement.executeUpdate();
			
			preparedStatement.close();
			connexion.close();
		}catch(Exception e) {
			System.out.println("boulette ajout en bdd !");
		}
	}
	
	
}
