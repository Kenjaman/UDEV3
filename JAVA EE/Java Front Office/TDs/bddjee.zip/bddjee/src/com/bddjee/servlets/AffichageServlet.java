package com.bddjee.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bddjee.bdd.Connexion;
import com.bddjee.bdd.ConnexionProd;


public class AffichageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String VUE_AFF = "/WEB-INF/jsp/affichage.jsp";    
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher(VUE_AFF);
		
		Connexion conClient = new Connexion();
		ConnexionProd conProduit = new ConnexionProd();
		request.setAttribute("clients", conClient.getConnexionClient());
		request.setAttribute("produits", conProduit.getConnexionProduit());
		
		dispatcher.forward(request, response);
	}


}
