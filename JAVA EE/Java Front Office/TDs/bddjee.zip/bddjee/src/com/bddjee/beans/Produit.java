package com.bddjee.beans;

public class Produit {
	private int code_produit;
	private String designation;
	private double prix_unitaire;
	private int disponible;
	private String photo_produit;
	
	public Produit(int code_produit, String designation, double prix_unitaire, int disponible,
			String photo_produit) {
		super();
		this.code_produit = code_produit;
		this.designation = designation;
		this.prix_unitaire = prix_unitaire;
		this.disponible = disponible;
		this.photo_produit = photo_produit;
	}

	public Produit() {
		super();
	}

	public int getCode_produit() {
		return code_produit;
	}

	public void setCode_produit(int code_produit) {
		this.code_produit = code_produit;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public double getPrix_unitaire() {
		return prix_unitaire;
	}

	public void setPrix_unitaire(double prix_unitaire) {
		this.prix_unitaire = prix_unitaire;
	}

	public int getDisponible() {
		return disponible;
	}

	public void setDisponible(int disponible) {
		this.disponible = disponible;
	}

	public String getPhoto_produit() {
		return photo_produit;
	}

	public void setPhoto_produit(String photo_produit) {
		this.photo_produit = photo_produit;
	}
	
	
	
}
