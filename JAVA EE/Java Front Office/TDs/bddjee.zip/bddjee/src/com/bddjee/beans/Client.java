package com.bddjee.beans;

public class Client {

	private int id;
	private String nom;
	private String adress;
	private String CP;
	private String ville;
	
	public Client() {
		super();
	}
	
	public Client(String nom, String adress, String cP, String ville) {
		super();
		this.nom = nom;
		this.adress = adress;
		this.CP = cP;
		this.ville = ville;
	}

	public int getId() {
		return id;
	}


	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public String getCP() {
		return CP;
	}

	public void setCP(String cP) {
		CP = cP;
	}

	public String getVille() {
		return ville;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}
	
	
	
}
