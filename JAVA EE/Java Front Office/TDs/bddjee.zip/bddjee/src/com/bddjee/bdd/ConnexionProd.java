package com.bddjee.bdd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.bddjee.beans.Produit;

public class ConnexionProd {
	
	public ArrayList<Produit> getConnexionProduit() {
		Connection connexionP = null;
		Statement statementP = null;
		ResultSet resultSetP = null;
		ArrayList<Produit> produits = new ArrayList<Produit>();
		
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			
			connexionP = DriverManager.getConnection("jdbc:mariadb://localhost:3306/frontjee", "root", "toor");
			System.out.println(connexionP);
			
			statementP = connexionP.createStatement();
			System.out.println(statementP);
			
			resultSetP = statementP.executeQuery("SELECT * FROM produit;");
			System.out.println(resultSetP);
			
			while(resultSetP.next()) {
				System.out.println(resultSetP.getString("code_produit"));
				System.out.println(resultSetP.getString("designation"));
				System.out.println(resultSetP.getString("prix_unitaire"));
				System.out.println(resultSetP.getString("disponible"));
				System.out.println(resultSetP.getString("photo_produit"));
				Produit produit = new Produit(resultSetP.getInt("code_produit"), resultSetP.getString("designation"), resultSetP.getDouble("prix_unitaire"), resultSetP.getInt("disponible"), resultSetP.getString("photo_produit"));
				
				
				produits.add(produit);
				
			}
			
			
			resultSetP.close();
			statementP.close();
			connexionP.close();
		}catch (Exception e) {
			System.out.println("boulette en bdd produit!") ;
		}
		
		return produits;
	}
}
