package com.bddjee.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bddjee.bdd.Connexion;
import com.bddjee.beans.Client;


public class ClientFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String VUE_FORM_CLIENT = "/WEB-INF/jsp/formClient.jsp";    
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher(VUE_FORM_CLIENT);
				
		
		dispatcher.forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher(VUE_FORM_CLIENT);
		Client client = new Client(request.getParameter("nom"), request.getParameter("adress"), request.getParameter("cp"), request.getParameter("ville"));
		Connexion conn = new Connexion();
		conn.getConnexionAjoutClient(client);
		
		response.sendRedirect(request.getContextPath() + "/");
	}

}
