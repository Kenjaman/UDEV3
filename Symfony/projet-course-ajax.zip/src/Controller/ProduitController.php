<?php

namespace App\Controller;

use App\Entity\Produit;
use App\Form\ProduitType;
use App\Repository\ProduitRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\JsonResponse;

class ProduitController extends AbstractController
{

    /**
     * @Route("/", name="liste_course", methods={"GET","POST"})
     */
    public function new(Request $request,ProduitRepository $produitRepository): Response
    {
        $produit = new Produit();
        $form = $this->createForm(ProduitType::class, $produit);
        $form->handleRequest($request);
        $produit->setEtat(true);
        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($produit);
            $entityManager->flush();

            return $this->redirectToRoute('liste_course');
        }

        return $this->render('produit/course.html.twig', [
            'produit' => $produit,
            'form' => $form->createView(),
            'produits' => $produitRepository->findAll(),
        ]);
    }


    /**
     * @Route("/effacer/{id}", name="produit_delete", methods={"GET"})
     */
    public function delete(Request $request, Produit $produit): Response
    {
        
        // to do csrf

        $entityManager = $this->getDoctrine()->getManager();
        $entityManager->remove($produit);
        $entityManager->flush();
        

        return $this->redirectToRoute('liste_course');
    }
    /**
     * @Route("/acheter/", name="produit_acheter")
     */
    public function acheter(Request $request): Response
    {
        $id=$request->request->get('id');
        $repo = $this->getDoctrine()->getRepository(Produit::class);
        $produit = $repo->find($id);
        
        if ($produit->getEtat()){
            $produit->setEtat(false);
        }else{
            $produit->setEtat(true);
        }
        
        $entityManager = $this->getDoctrine()->getManager();
        $entityManager->persist($produit);
        $entityManager->flush();
        
        return new JsonResponse(['id' => $id]);
    }

}
