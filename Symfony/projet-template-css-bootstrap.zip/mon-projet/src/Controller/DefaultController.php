<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;

class DefaultController extends AbstractController
{
    /**
     * @Route("/", name="default_home")
     */
    public function home()
    {
        $titre="HOME";
        return $this->render('default/home.html.twig',
            compact("titre"));
    }
    /**
     * @Route("/about", name="default_about")
     */
    public function about()
    {
        $titre="About";
        return $this->render('default/home.html.twig',
            compact("titre"));
    }
    /**
     * @Route("/projects", name="default_projects")
     */
    public function projects()
    {
        $titre="Projects";
        return $this->render('default/home.html.twig',
            compact("titre"));
    }
    /**
     * @Route("/contact", name="default_contact")
     */
    public function contact()
    {
        $titre="CONTACT";
        return $this->render('default/home.html.twig',
            compact("titre"));
    }

}
