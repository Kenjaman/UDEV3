<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* default/demo.html.twig */
class __TwigTemplate_5a2fe1ba866461b9685836b965140838877b0175982e22efde18888e90d8e99d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "default/demo.html.twig"));

        $this->parent = $this->loadTemplate("layout.html.twig", "default/demo.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "demo |";
        $this->displayParentBlock("title", $context, $blocks);
        echo " ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 4
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "main"));

        // line 5
        echo "
<h1> Je suis twig et je suis ";
        // line 6
        echo twig_escape_filter($this->env, (isset($context["info"]) || array_key_exists("info", $context) ? $context["info"] : (function () { throw new RuntimeError('Variable "info" does not exist.', 6, $this->source); })()), "html", null, true);
        echo "</h1>
";
        // line 7
        $context["str"] = "ola";
        // line 8
        echo "
<h2>";
        // line 9
        echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, (isset($context["str"]) || array_key_exists("str", $context) ? $context["str"] : (function () { throw new RuntimeError('Variable "str" does not exist.', 9, $this->source); })())), "html", null, true);
        echo "</h2>
";
        // line 11
        $context["fruits"] = [0 => "kiwi", 1 => "pomme", 2 => "cerise"];
        // line 12
        echo "
<ul>
\t";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["fruits"]) || array_key_exists("fruits", $context) ? $context["fruits"] : (function () { throw new RuntimeError('Variable "fruits" does not exist.', 14, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["fruit"]) {
            // line 15
            echo "\t\t";
            if (0 !== twig_compare($context["fruit"], "pomme")) {
                // line 16
                echo "\t\t\t<li>";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 16), "html", null, true);
                echo "  - ";
                echo twig_escape_filter($this->env, twig_upper_filter($this->env, $context["fruit"]), "html", null, true);
                echo "</li>
\t\t";
            }
            // line 18
            echo "\t
\t";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fruit'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo "</ul>
";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tab"]) || array_key_exists("tab", $context) ? $context["tab"] : (function () { throw new RuntimeError('Variable "tab" does not exist.', 21, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 22
            echo "<p>";
            echo twig_escape_filter($this->env, $context["p"], "html", null, true);
            echo "</p>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo twig_escape_filter($this->env, twig_join_filter((isset($context["tab"]) || array_key_exists("tab", $context) ? $context["tab"] : (function () { throw new RuntimeError('Variable "tab" does not exist.', 24, $this->source); })()), ","), "html", null, true);
        echo "
<h3>";
        // line 25
        echo twig_escape_filter($this->env, twig_length_filter($this->env, (isset($context["str"]) || array_key_exists("str", $context) ? $context["str"] : (function () { throw new RuntimeError('Variable "str" does not exist.', 25, $this->source); })())), "html", null, true);
        echo "</h3>
";
        // line 26
        $context["ca"] = 123456789.888888;
        // line 27
        echo "<h4>";
        echo twig_number_format_filter($this->env, (isset($context["ca"]) || array_key_exists("ca", $context) ? $context["ca"] : (function () { throw new RuntimeError('Variable "ca" does not exist.', 27, $this->source); })()), 2, ",", "&nbsp;");
        echo "</h4>
1 nb de chiffre apres la virg.
2 remplacer la virgule
3 l'espace entre 1000
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "default/demo.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  166 => 27,  164 => 26,  160 => 25,  156 => 24,  147 => 22,  143 => 21,  140 => 20,  125 => 18,  117 => 16,  114 => 15,  97 => 14,  93 => 12,  91 => 11,  87 => 9,  84 => 8,  82 => 7,  78 => 6,  75 => 5,  68 => 4,  53 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'layout.html.twig' %}
{% block title %}demo |{{ parent() }} {% endblock %}

{% block main %}

<h1> Je suis twig et je suis {{ info }}</h1>
{% set  str = 'ola' %}

<h2>{{ str|capitalize }}</h2>
{#  des commentaires #}
{% set fruits= ['kiwi','pomme','cerise'] %}

<ul>
\t{% for fruit in fruits %}
\t\t{% if fruit != 'pomme' %}
\t\t\t<li>{{ loop.index }}  - {{ fruit|upper }}</li>
\t\t{% endif %}
\t
\t{% endfor %}
</ul>
{% for p in tab %}
<p>{{ p }}</p>
{% endfor %}
{{ tab|join(',') }}
<h3>{{ str|length }}</h3>
{% set ca= 123456789.888888 %}
<h4>{{ ca|number_format(2 ,',','&nbsp;')|raw }}</h4>
1 nb de chiffre apres la virg.
2 remplacer la virgule
3 l'espace entre 1000
{% endblock %}", "default/demo.html.twig", "C:\\wamp64\\www\\symfony\\mon-projet\\templates\\default\\demo.html.twig");
    }
}
