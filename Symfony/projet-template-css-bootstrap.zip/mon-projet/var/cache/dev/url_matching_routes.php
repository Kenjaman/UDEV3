<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/' => [[['_route' => 'default_home', '_controller' => 'App\\Controller\\DefaultController::home'], null, null, null, false, false, null]],
        '/about' => [[['_route' => 'default_about', '_controller' => 'App\\Controller\\DefaultController::about'], null, null, null, false, false, null]],
        '/projects' => [[['_route' => 'default_projects', '_controller' => 'App\\Controller\\DefaultController::projects'], null, null, null, false, false, null]],
        '/contact' => [[['_route' => 'default_contact', '_controller' => 'App\\Controller\\DefaultController::contact'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [
            [['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
