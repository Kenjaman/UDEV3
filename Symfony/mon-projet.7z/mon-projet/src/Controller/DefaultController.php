<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;

class DefaultController extends AbstractController
{
    /**
     * @Route("/default", name="default_index")
     */
    public function index()
    {

        die("<h1>Hello world</h1>");
        /*
        return $this->render('default/index.html.twig', [
            'controller_name' => 'DefaultController',
        ]);
        */
    }

   /**
     * @Route("/", name="default_home")
     */
    public function home()
    {
    	$str = "<h2> OLA</h2>";
    	//echo $str;
    	//return new Response($str); // HTML ou JSON Brut
        return $this->render('default/home.html.twig');
        
    }
    /**
     * @Route("/demo", name="default_demo")
     */
    public function demo()
    {
        $tab = ['Morty','Jessica','Summer','Jerry'];
        $info = "Rick Sanchez";
//        return $this->render('default/demo.html.twig',
//            [
//                'info' => $info,
//                'tab' => $tab
//
//        ]);
        return $this->render('default/demo.html.twig', compact('info','tab')); // $this->>render pour Twig

    }
}
