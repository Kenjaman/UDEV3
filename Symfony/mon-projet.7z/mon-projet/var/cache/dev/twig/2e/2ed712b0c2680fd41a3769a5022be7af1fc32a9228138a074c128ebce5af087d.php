<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* default/demo.html.twig */
class __TwigTemplate_cefe2ee05cb20eed4e886fd9a5782f6ee3634b0c37131fad0df44fe25cc60d68 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "default/demo.html.twig"));

        $this->parent = $this->loadTemplate("layout.html.twig", "default/demo.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "main"));

        // line 3
        echo "<h1>Je s'appel Twig ! et je te balance ";
        echo twig_escape_filter($this->env, (isset($context["info"]) || array_key_exists("info", $context) ? $context["info"] : (function () { throw new RuntimeError('Variable "info" does not exist.', 3, $this->source); })()), "html", null, true);
        echo "</h1>
";
        // line 4
        $context["str"] = "hola";
        // line 5
        echo "
<h2>";
        // line 6
        echo twig_escape_filter($this->env, (isset($context["str"]) || array_key_exists("str", $context) ? $context["str"] : (function () { throw new RuntimeError('Variable "str" does not exist.', 6, $this->source); })()), "html", null, true);
        echo "</h2>

";
        // line 8
        $context["fruits"] = [0 => "kiwi", 1 => "pomme", 2 => "cerise"];
        // line 9
        echo "
<ul>
    ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["fruits"]) || array_key_exists("fruits", $context) ? $context["fruits"] : (function () { throw new RuntimeError('Variable "fruits" does not exist.', 11, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["fruit"]) {
            // line 12
            echo "        ";
            if (0 !== twig_compare($context["fruit"], "pomme")) {
                // line 13
                echo "    <li>";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 13), "html", null, true);
                echo " - ";
                echo twig_escape_filter($this->env, $context["fruit"], "html", null, true);
                echo "</li>
        ";
            }
            // line 15
            echo "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fruit'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "</ul>
";
        // line 17
        echo twig_escape_filter($this->env, twig_join_filter((isset($context["tab"]) || array_key_exists("tab", $context) ? $context["tab"] : (function () { throw new RuntimeError('Variable "tab" does not exist.', 17, $this->source); })()), " et "), "html", null, true);
        echo "
<h3>";
        // line 18
        echo twig_escape_filter($this->env, twig_length_filter($this->env, (isset($context["fruits"]) || array_key_exists("fruits", $context) ? $context["fruits"] : (function () { throw new RuntimeError('Variable "fruits" does not exist.', 18, $this->source); })())), "html", null, true);
        echo "</h3>
";
        // line 19
        $context["ca"] = 12345678.888888;
        // line 20
        echo "<h4> ";
        echo twig_number_format_filter($this->env, (isset($context["ca"]) || array_key_exists("ca", $context) ? $context["ca"] : (function () { throw new RuntimeError('Variable "ca" does not exist.', 20, $this->source); })()), 2, ",", "&nbsp;");
        echo "</h4>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "default/demo.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  135 => 20,  133 => 19,  129 => 18,  125 => 17,  122 => 16,  108 => 15,  100 => 13,  97 => 12,  80 => 11,  76 => 9,  74 => 8,  69 => 6,  66 => 5,  64 => 4,  59 => 3,  52 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'layout.html.twig' %}
{% block main %}
<h1>Je s'appel Twig ! et je te balance {{ info }}</h1>
{% set str = 'hola' %}

<h2>{{ str  }}</h2>

{%  set fruits = ['kiwi','pomme','cerise'] %}

<ul>
    {% for fruit in fruits %}
        {% if fruit != 'pomme' %}
    <li>{{ loop.index }} - {{ fruit }}</li>
        {% endif %}
    {% endfor %}
</ul>
{{ tab|join(' et ') }}
<h3>{{ fruits |length }}</h3>
{% set ca = 12345678.888888 %}
<h4> {{ ca | number_format(2,',','&nbsp;')|raw}}</h4>
{% endblock %}", "default/demo.html.twig", "C:\\wamp64\\www\\symfony\\mon-projet\\templates\\default\\demo.html.twig");
    }
}
