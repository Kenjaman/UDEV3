import { Component, OnInit } from '@angular/core';
import { Personne} from "../model/personne";

@Component({
  selector: 'app-tp-tableau-person',
  templateUrl: './tp-tableau-person.component.html',
  styleUrls: ['./tp-tableau-person.component.scss']
})
export class TPTableauPersonComponent implements OnInit {
  nom:string;
  prenom:string;
  sexe:string='homme';
  tab:Personne[]=[
    new Personne('Rick','Sanchez', 'homme'),
    new Personne('Sanchez','Morty','homme')
  ];

  ngOnInit() {
    let p:Personne = new Personne('Jessica','Juste','femme');
    this.tab.push(p);
    console.log(this.tab);
  }
  onEnlever(index:number):void{
    this.tab.splice(index,1);
  }

  onAjouter():void{
    let person:Personne={nom:this.nom,
      prenom:this.prenom,
      sexe :this.sexe};
    this.tab.push(person);
    this.nom="";
    this.prenom="";
    this.sexe="";
  }

}
